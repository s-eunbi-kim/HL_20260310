
void noPrototype () {
     stub ();
}